<?php


ShortcodeParser::get('default')->register('groupdocsDotNetViewer', array('groupdocsDotNetViewer', 'handle_shortcode'));
